package com.niit.dao;

import java.util.List;

import com.niit.entity.Face;



public interface IFaceDao {

	public List<Face> selectAllUsers();

}
