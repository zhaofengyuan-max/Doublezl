package com.niit.biz;

import java.util.List;

import com.niit.entity.Face;

public interface IFaceBiz {

	public List<Face> selectAllUsers();

}
