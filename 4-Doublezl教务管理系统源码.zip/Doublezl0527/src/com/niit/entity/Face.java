package com.niit.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="face")
public class Face {
	
	 @Id 
	 @GeneratedValue(strategy = GenerationType.SEQUENCE)
	 @Column(name="Id", unique=true, nullable=false, length=32)
     private int id;
	 @Column(name="Base64", nullable=false)
	 private byte[] base64;
	 
	 
	//
	public Face() {

	}
	

	public Face(int id, byte[] base64) {
		super();
		this.id = id;
		this.base64 = base64;
	}


	public byte[] getBase64() {
		return base64;
	}

	public void setBase64(byte[] base64) {
		this.base64 = base64;
	}




	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


}
