var menu = {
	/*'home' : {
		title : '首页',
		menu : [ {
			title : '首页',
			icon : 'imgs/main/l03.png',
			href : 'project/index.jsp',

		}
		
		]
	},*/

	'project' : {
		title : '信息查询',
		menu : [  {
			title : '学籍信息',
			icon : 'imgs/main/l01.png',
			href : 'project/selectSroll.jsp',
			isCurrent : true
		},
		         {
			title: '专业信息',
			icon : 'imgs/main/l02.png',
			href : 'adminLittleAction!findAllMajor',
			
		}, {
			title : '教室信息',
			icon : 'imgs/main/l03.png',
			href : 'adminLittleAction!findAllRoom'
		}, {
			title : '教师信息',
			icon : 'imgs/main/l04.png',
			href : 'adminAction!selectAllTeacher'
		}, {
			title : '课表信息',
			icon : 'imgs/main/l05.png',
			href : 'adminAction!selectSchoolCourse'
		}, {
			title : '班级信息',
			icon : 'imgs/main/l06.png',
			href : 'adminAction!selectAllSclass'
		}, {
			title : '选课信息',
			icon : 'imgs/main/l07.png',
			href : 'adminAction!selectAllExcourse'
		}, {
			title : '成绩信息',
			icon : 'imgs/main/l08.png',
			href : 'project/selectGrade.jsp'
		} ]
	},

	'query' : {
		title : '教学评估',
		menu : [

		{
			title : '上传教学评估表',
			icon : 'imgs/main/l12.png',
			href : 'query/addQuestion.jsp',
			isCurrent : true
		}, {
			title : '查看评估表',
			icon : 'imgs/main/l14.png',
			href : 'adminAction!selectAllQuestion'
		},
		]
	},

	'mange' : {
		title : '录入管理',
		menu : [ {
			title : '专业录入',
			icon : 'imgs/main/l17.png',
			isCurrent : true,
			href : 'backend/addMajor.jsp'
		}, {
			title : '教室录入',
			icon : 'imgs/main/l18.png',
			href : 'backend/addRoom.jsp'
		}, {
			title : '教师录入',
			icon : 'imgs/main/l19.png',
			href : 'pages/addTeacher.jsp'
		}, {
			title : '班级录入',
			icon : 'imgs/main/l20.png',
			href : 'backend/minzhu/addClass.jsp'

		},  {

			title : '课程录入',
			icon : 'imgs/main/l22.png',
			href : 'backend/addCourse.jsp'
		}, {
			title : '选课录入',
			icon : 'imgs/main/l23.png',
			href : 'backend/addExCourse.jsp'
		}, {
			title : '学籍/学生登记',
			icon : 'imgs/main/l27.png',
			href : 'backend/addSroll.jsp'
		} 

		]
	}
};