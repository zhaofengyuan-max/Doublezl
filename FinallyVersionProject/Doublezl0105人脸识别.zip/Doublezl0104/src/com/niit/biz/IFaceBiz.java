package com.niit.biz;

import java.util.List;

import com.niit.entity.User;

public interface IFaceBiz {

	public List<User> selectAllUsers();

}
