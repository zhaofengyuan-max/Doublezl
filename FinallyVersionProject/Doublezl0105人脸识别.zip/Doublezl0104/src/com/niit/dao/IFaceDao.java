package com.niit.dao;

import java.util.List;

import com.niit.entity.User;



public interface IFaceDao {

	public List<User> selectAllUsers();

}
